#include <iostream>
#include "dssanpham.h"

using namespace std;

void hienThiMenu() {
    cout << "\n===== CHUONG TRINH QUAN LY DANH SACH SAN PHAM =====" << endl;
    cout << "1. Hien thi danh sach" << endl;
    cout << "2. Them san pham" << endl;
    cout << "3. Cap nhat san pham" << endl;
    cout << "4. Xoa san pham theo ma" << endl;
    cout << "5. Thoat" << endl;
    cout << "Chon chuc nang: ";
}

int main() {
    DSSanPham ds;
    khoiTao(ds);
    int luaChon;

    do {
        hienThiMenu();
        cin >> luaChon;

        switch (luaChon) {
            case 1: {
                hienThiDanhSach(ds);
                break;
            }
            case 2: {
                int ma;
                cout << "Nhap ma san pham: ";
                cin >> ma;

                int viTri = timTheoMa(ds, ma);
                if (viTri != -1) {
                    cout << "Ma " << ma << " da ton tai (" << ds.a[viTri].ten << ")." << endl;
                    int soLuongThem;
                    cout << "Nhap so luong can them: ";
                    cin >> soLuongThem;
                    themSanPham(ds, ma, ds.a[viTri].ten, soLuongThem);
                } else {
                    string ten;
                    int soluong;
                    cout << "Nhap ten san pham: ";
                    cin >> ten;
                    cout << "Nhap so luong: ";
                    cin >> soluong;
                    themSanPham(ds, ma, ten, soluong);
                }
                break;
            }
            case 3: {
                int maCu, maMoi;
                string tenMoi;
                cout << "Nhap ma san pham can cap nhat: ";
                cin >> maCu;
                cout << "Nhap ma moi: ";
                cin >> maMoi;
                cout << "Nhap ten moi: ";
                cin >> tenMoi;
                capNhatSanPham(ds, maCu, maMoi, tenMoi);
                break;
            }
            case 4: {
                int ma;
                cout << "Nhap ma san pham can xoa: ";
                cin >> ma;
                xoaTheoMa(ds, ma);
                break;
            }
            case 5: {
                cout << "Ket thuc chuong trinh!" << endl;
                break;
            }
            default: {
                cout << "Lua chon khong hop le, vui long chon lai!" << endl;
                break;
            }
        }
    } while (luaChon != 5);

    return 0;
}
