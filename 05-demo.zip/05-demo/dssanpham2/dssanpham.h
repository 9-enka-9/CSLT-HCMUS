#ifndef DSSANPHAM_H
#define DSSANPHAM_H

#include <string>
#include "sanpham.h"

struct DSSanPham {
    SanPham a[MAX];
    int n;
};

// Khoi tao danh sach rong
void khoiTao(DSSanPham &ds);

// Hiển thị danh sách sản phẩm
void hienThiDanhSach(DSSanPham &ds);

// Tìm vị trí (index) sản phẩm theo mã, tra ve -1 neu khong tim thay
int timTheoMa(DSSanPham &ds, int ma);

// Thêm sản phẩm. Neu ma da ton tai thi chi cong don so luong
void themSanPham(DSSanPham &ds, int ma, std::string ten, int soluong);

// Cập nhật mã và tên của sản phẩm đang có mã la maCu
void capNhatSanPham(DSSanPham &ds, int maCu, int maMoi, std::string tenMoi);

// Xóa sản phẩm theo mã
void xoaTheoMa(DSSanPham &ds, int ma);

#endif
