#ifndef SANPHAM_H
#define SANPHAM_H

#include <string>

const int MAX = 100;

struct SanPham {
    int ma;
    std::string ten;
    int soluong;
};

#endif
