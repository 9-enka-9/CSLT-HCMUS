#include <iostream>
#include "dssanpham.h"

using namespace std;

void khoiTao(DSSanPham &ds) {
    ds.n = 0;
}

void hienThiDanhSach(DSSanPham &ds) {
    if (ds.n == 0) {
        cout << "Danh sach rong!" << endl;
        return;
    }
    cout << "Danh sach gom " << ds.n << " san pham:" << endl;
    cout << "Ma\tTen\t\tSo luong" << endl;
    for (int i = 0; i < ds.n; i++) {
        cout << ds.a[i].ma << "\t" << ds.a[i].ten << "\t\t" << ds.a[i].soluong << endl;
    }
}

int timTheoMa(DSSanPham &ds, int ma) {
    for (int i = 0; i < ds.n; i++) {
        if (ds.a[i].ma == ma) {
            return i;
        }
    }
    return -1;
}

void themSanPham(DSSanPham &ds, int ma, string ten, int soluong) {
    int viTri = timTheoMa(ds, ma);
    if (viTri != -1) {
        ds.a[viTri].soluong += soluong;
        cout << "Ma " << ma << " da ton tai, da cong don so luong. So luong moi: " << ds.a[viTri].soluong << endl;
        return;
    }

    if (ds.n >= MAX) {
        cout << "Danh sach da day, khong the them!" << endl;
        return;
    }

    ds.a[ds.n].ma = ma;
    ds.a[ds.n].ten = ten;
    ds.a[ds.n].soluong = soluong;
    ds.n++;
    cout << "Da them san pham moi." << endl;
}

void capNhatSanPham(DSSanPham &ds, int maCu, int maMoi, string tenMoi) {
    int viTri = timTheoMa(ds, maCu);
    if (viTri == -1) {
        cout << "Khong tim thay san pham co ma " << maCu << "!" << endl;
        return;
    }

    if (maMoi != maCu) {
        int viTriTrung = timTheoMa(ds, maMoi);
        if (viTriTrung != -1) {
            cout << "Ma " << maMoi << " da ton tai o san pham khac, khong the cap nhat!" << endl;
            return;
        }
    }

    ds.a[viTri].ma = maMoi;
    ds.a[viTri].ten = tenMoi;
    cout << "Da cap nhat san pham." << endl;
}

void xoaTheoMa(DSSanPham &ds, int ma) {
    int viTri = timTheoMa(ds, ma);
    if (viTri == -1) {
        cout << "Khong tim thay san pham co ma " << ma << "!" << endl;
        return;
    }

    for (int i = viTri; i < ds.n - 1; i++) {
        ds.a[i] = ds.a[i + 1];
    }
    ds.n--;
    cout << "Da xoa san pham co ma " << ma << "." << endl;
}
