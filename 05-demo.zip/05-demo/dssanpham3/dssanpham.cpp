#include <iostream>
#include "dssanpham.h"

using namespace std;

void khoiTao(DSSanPham &ds) {
    ds.n = 0;
}

void hienThiDanhSach(DSSanPham &ds) {
    if (ds.n == 0) {
        cout << "Danh sach rong!" << endl;
        return;
    }
    cout << "Danh sach gom " << ds.n << " san pham:" << endl;
    cout << "Ma\tTen\t\tSo luong" << endl;
    for (int i = 0; i < ds.n; i++) {
        xuatSanPham(ds.a[i]);
    }
}

int timTheoMa(DSSanPham &ds, int ma) {
    for (int i = 0; i < ds.n; i++) {
        if (ds.a[i].ma == ma) {
            return i;
        }
    }
    return -1;
}

void themSanPham(DSSanPham &ds) {
    int ma;
    cout << "Nhap ma san pham: ";
    cin >> ma;

    int viTri = timTheoMa(ds, ma);
    if (viTri != -1) {
        cout << "Ma " << ma << " da ton tai (" << ds.a[viTri].ten << ")." << endl;
        int soLuongThem;
        cout << "Nhap so luong can them: ";
        cin >> soLuongThem;
        ds.a[viTri].soluong += soLuongThem;
        cout << "Da cong don so luong. So luong moi: " << ds.a[viTri].soluong << endl;
        return;
    }

    if (ds.n >= MAX) {
        cout << "Danh sach da day, khong the them!" << endl;
        return;
    }

    SanPham sp;
    sp.ma = ma;
    nhapSanPham(sp, false);
    ds.a[ds.n] = sp;
    ds.n++;
    cout << "Da them san pham moi." << endl;
}

void capNhatSanPham(DSSanPham &ds) {
    int maCu;
    cout << "Nhap ma san pham can cap nhat: ";
    cin >> maCu;

    int viTri = timTheoMa(ds, maCu);
    if (viTri == -1) {
        cout << "Khong tim thay san pham co ma " << maCu << "!" << endl;
        return;
    }

    int maMoi;
    string tenMoi;
    nhapMaVaTen(maMoi, tenMoi);

    if (maMoi != maCu && timTheoMa(ds, maMoi) != -1) {
        cout << "Ma " << maMoi << " da ton tai o san pham khac, khong the cap nhat!" << endl;
        return;
    }

    ds.a[viTri].ma = maMoi;
    ds.a[viTri].ten = tenMoi;
    cout << "Da cap nhat san pham." << endl;
}

void xoaTheoMa(DSSanPham &ds) {
    int ma;
    cout << "Nhap ma san pham can xoa: ";
    cin >> ma;

    int viTri = timTheoMa(ds, ma);
    if (viTri == -1) {
        cout << "Khong tim thay san pham co ma " << ma << "!" << endl;
        return;
    }

    for (int i = viTri; i < ds.n - 1; i++) {
        ds.a[i] = ds.a[i + 1];
    }
    ds.n--;
    cout << "Da xoa san pham co ma " << ma << "." << endl;
}
