#ifndef SANPHAM_H
#define SANPHAM_H

#include <string>

const int MAX = 100;

struct SanPham {
    int ma;
    std::string ten;
    int soluong;
};

// Nhap thong tin 1 san pham. Neu nhapMa = false thi giu nguyen sp.ma dang co,
// chi nhap ten va so luong (dung khi ma da duoc xac dinh truoc do).
void nhapSanPham(SanPham &sp, bool nhapMa = true);

// Nhap ma moi va ten moi (dung khi cap nhat san pham)
void nhapMaVaTen(int &ma, std::string &ten);

// Xuat thong tin 1 san pham (1 dong)
void xuatSanPham(const SanPham &sp);

#endif
