#include <iostream>
#include "dssanpham.h"

using namespace std;

void hienThiMenu() {
    cout << "\n===== CHUONG TRINH QUAN LY DANH SACH SAN PHAM =====" << endl;
    cout << "1. Hien thi danh sach" << endl;
    cout << "2. Them san pham" << endl;
    cout << "3. Cap nhat san pham" << endl;
    cout << "4. Xoa san pham theo ma" << endl;
    cout << "5. Thoat" << endl;
    cout << "Chon chuc nang: ";
}

int main() {
    DSSanPham ds;
    khoiTao(ds);
    int luaChon;

    do {
        hienThiMenu();
        cin >> luaChon;

        switch (luaChon) {
            case 1: {
                hienThiDanhSach(ds);
                break;
            }
            case 2: {
                themSanPham(ds);
                break;
            }
            case 3: {
                capNhatSanPham(ds);
                break;
            }
            case 4: {
                xoaTheoMa(ds);
                break;
            }
            case 5: {
                cout << "Ket thuc chuong trinh!" << endl;
                break;
            }
            default: {
                cout << "Lua chon khong hop le, vui long chon lai!" << endl;
                break;
            }
        }
    } while (luaChon != 5);

    return 0;
}
