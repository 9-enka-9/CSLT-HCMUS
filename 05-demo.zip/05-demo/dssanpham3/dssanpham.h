#ifndef DSSANPHAM_H
#define DSSANPHAM_H

#include "sanpham.h"

struct DSSanPham {
    SanPham a[MAX];
    int n;
};

// Khoi tao danh sach rong
void khoiTao(DSSanPham &ds);

// Hien thi danh sach san pham
void hienThiDanhSach(DSSanPham &ds);

// Tim vi tri (index) san pham theo ma, tra ve -1 neu khong tim thay
int timTheoMa(DSSanPham &ds, int ma);

// Them san pham. Tu nhap ma; neu ma da ton tai thi chi nhap so luong can them
void themSanPham(DSSanPham &ds);

// Cap nhat ma va ten cua 1 san pham dang co. Tu nhap ma can sua va ma/ten moi
void capNhatSanPham(DSSanPham &ds);

// Xoa san pham theo ma. Tu nhap ma can xoa
void xoaTheoMa(DSSanPham &ds);

#endif
