#include <iostream>
#include "sanpham.h"

using namespace std;

void nhapSanPham(SanPham &sp, bool nhapMa) {
    if (nhapMa) {
        cout << "Nhap ma san pham: ";
        cin >> sp.ma;
    }
    cout << "Nhap ten san pham: ";
    cin >> sp.ten;
    cout << "Nhap so luong: ";
    cin >> sp.soluong;
}

void nhapMaVaTen(int &ma, string &ten) {
    cout << "Nhap ma moi: ";
    cin >> ma;
    cout << "Nhap ten moi: ";
    cin >> ten;
}

void xuatSanPham(const SanPham &sp) {
    cout << sp.ma << "\t" << sp.ten << "\t\t" << sp.soluong << endl;
}
