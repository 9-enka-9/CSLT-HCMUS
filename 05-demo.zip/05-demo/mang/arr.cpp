#include <iostream>
#include "arr.h"

using namespace std;

void hienThiDanhSach(int a[], int n) {
    if (n == 0) {
        cout << "Danh sach rong!" << endl;
        return;
    }
    cout << "Danh sach gom " << n << " phan tu:" << endl;
    for (int i = 0; i < n; i++) {
        cout << a[i] << " ";
    }
    cout << endl;
}

void themPhanTu(int a[], int &n, int giaTri, int viTri) {
    if (n >= MAX) {
        cout << "Danh sach da day, khong the them!" << endl;
        return;
    }
    if (viTri < 1 || viTri > n + 1) {
        cout << "Vi tri khong hop le!" << endl;
        return;
    }

    for (int i = n; i >= viTri; i--) {
        a[i] = a[i - 1];
    }
    a[viTri - 1] = giaTri;
    n++;
}

void xoaTheoGiaTri(int a[], int &n, int giaTri) {
    int soLuongXoa = 0;
    int i = 0;
    while (i < n) {
        if (a[i] == giaTri) {
            for (int j = i; j < n - 1; j++) {
                a[j] = a[j + 1];
            }
            n--;
            soLuongXoa++;
        } else {
            i++;
        }
    }

    if (soLuongXoa == 0) {
        cout << "Khong tim thay gia tri " << giaTri << " trong danh sach!" << endl;
    } else {
        cout << "Da xoa " << soLuongXoa << " phan tu co gia tri " << giaTri << "." << endl;
    }
}

void xoaTheoViTri(int a[], int &n, int viTri) {
    if (viTri < 1 || viTri > n) {
        cout << "Vi tri khong hop le!" << endl;
        return;
    }

    for (int i = viTri - 1; i < n - 1; i++) {
        a[i] = a[i + 1];
    }
    n--;
    cout << "Da xoa phan tu o vi tri " << viTri << "." << endl;
}
