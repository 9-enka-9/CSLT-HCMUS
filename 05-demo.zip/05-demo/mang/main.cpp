#include <iostream>
#include "arr.h"

using namespace std;

void hienThiMenu() {
    cout << "\n===== CHUONG TRINH QUAN LY DANH SACH SO NGUYEN =====" << endl;
    cout << "1. Hien thi danh sach" << endl;
    cout << "2. Them phan tu vao danh sach" << endl;
    cout << "3. Xoa phan tu theo gia tri" << endl;
    cout << "4. Xoa phan tu theo vi tri" << endl;
    cout << "5. Thoat" << endl;
    cout << "Chon chuc nang: ";
}

int main() {
    int a[MAX];
    int n = 0;
    int luaChon;

    do {
        hienThiMenu();
        cin >> luaChon;

        switch (luaChon) {
            case 1: {
                hienThiDanhSach(a, n);
                break;
            }
            case 2: {
                int giaTri, viTri;
                cout << "Nhap gia tri can them: ";
                cin >> giaTri;
                cout << "Nhap vi tri can them (tu 1 den " << n + 1 << "): ";
                cin >> viTri;
                themPhanTu(a, n, giaTri, viTri);
                break;
            }
            case 3: {
                int giaTri;
                cout << "Nhap gia tri can xoa: ";
                cin >> giaTri;
                xoaTheoGiaTri(a, n, giaTri);
                break;
            }
            case 4: {
                int viTri;
                cout << "Nhap vi tri can xoa: ";
                cin >> viTri;
                xoaTheoViTri(a, n, viTri);
                break;
            }
            case 5: {
                cout << "Ket thuc chuong trinh!" << endl;
                break;
            }
            default: {
                cout << "Lua chon khong hop le, vui long chon lai!" << endl;
                break;
            }
        }
    } while (luaChon != 5);

    return 0;
}
