#ifndef ARR_H
#define ARR_H

const int MAX = 100;

// Hiển thị danh sách
void hienThiDanhSach(int a[], int n);

// Thêm phần tử giaTri vào vị trí viTri (vị trí tính từ 1)
void themPhanTu(int a[], int &n, int giaTri, int viTri);

// Xóa tất cả phần tử có giá trị bằng giaTri
void xoaTheoGiaTri(int a[], int &n, int giaTri);

// Xóa phần tử ở vị trí viTri (vị trí tính từ 1)
void xoaTheoViTri(int a[], int &n, int viTri);

#endif
