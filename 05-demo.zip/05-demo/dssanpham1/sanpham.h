#ifndef SANPHAM_H
#define SANPHAM_H

#include <string>

const int MAX = 100;

struct SanPham {
    int ma;
    std::string ten;
    int soluong;
};

// Hiển thị danh sách sản phẩm
void hienThiDanhSach(SanPham a[], int n);

// Tìm vị trí (index) sản phẩm theo mã, tra ve -1 neu khong tim thay
int timTheoMa(SanPham a[], int n, int ma);

// Thêm sản phẩm. Neu ma da ton tai thi chi cong don so luong
void themSanPham(SanPham a[], int &n, int ma, std::string ten, int soluong);

// Cập nhật mã và tên của sản phẩm đang có mã la maCu
void capNhatSanPham(SanPham a[], int n, int maCu, int maMoi, std::string tenMoi);

// Xóa sản phẩm theo mã
void xoaTheoMa(SanPham a[], int &n, int ma);

#endif
