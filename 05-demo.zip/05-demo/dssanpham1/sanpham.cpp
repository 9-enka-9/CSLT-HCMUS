#include <iostream>
#include "sanpham.h"

using namespace std;

void hienThiDanhSach(SanPham a[], int n) {
    if (n == 0) {
        cout << "Danh sach rong!" << endl;
        return;
    }
    cout << "Danh sach gom " << n << " san pham:" << endl;
    cout << "Ma\tTen\t\tSo luong" << endl;
    for (int i = 0; i < n; i++) {
        cout << a[i].ma << "\t" << a[i].ten << "\t\t" << a[i].soluong << endl;
    }
}

int timTheoMa(SanPham a[], int n, int ma) {
    for (int i = 0; i < n; i++) {
        if (a[i].ma == ma) {
            return i;
        }
    }
    return -1;
}

void themSanPham(SanPham a[], int &n, int ma, string ten, int soluong) {
    int viTri = timTheoMa(a, n, ma);
    if (viTri != -1) {
        a[viTri].soluong += soluong;
        cout << "Ma " << ma << " da ton tai, da cong don so luong. So luong moi: " << a[viTri].soluong << endl;
        return;
    }

    if (n >= MAX) {
        cout << "Danh sach da day, khong the them!" << endl;
        return;
    }

    a[n].ma = ma;
    a[n].ten = ten;
    a[n].soluong = soluong;
    n++;
    cout << "Da them san pham moi." << endl;
}

void capNhatSanPham(SanPham a[], int n, int maCu, int maMoi, string tenMoi) {
    int viTri = timTheoMa(a, n, maCu);
    if (viTri == -1) {
        cout << "Khong tim thay san pham co ma " << maCu << "!" << endl;
        return;
    }

    if (maMoi != maCu) {
        int viTriTrung = timTheoMa(a, n, maMoi);
        if (viTriTrung != -1) {
            cout << "Ma " << maMoi << " da ton tai o san pham khac, khong the cap nhat!" << endl;
            return;
        }
    }

    a[viTri].ma = maMoi;
    a[viTri].ten = tenMoi;
    cout << "Da cap nhat san pham." << endl;
}

void xoaTheoMa(SanPham a[], int &n, int ma) {
    int viTri = timTheoMa(a, n, ma);
    if (viTri == -1) {
        cout << "Khong tim thay san pham co ma " << ma << "!" << endl;
        return;
    }

    for (int i = viTri; i < n - 1; i++) {
        a[i] = a[i + 1];
    }
    n--;
    cout << "Da xoa san pham co ma " << ma << "." << endl;
}
