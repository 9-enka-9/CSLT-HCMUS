#include <iostream>
#include "sanpham.h"

using namespace std;

void hienThiMenu() {
    cout << "\n===== CHUONG TRINH QUAN LY DANH SACH SAN PHAM =====" << endl;
    cout << "1. Hien thi danh sach" << endl;
    cout << "2. Them san pham" << endl;
    cout << "3. Cap nhat san pham" << endl;
    cout << "4. Xoa san pham theo ma" << endl;
    cout << "5. Thoat" << endl;
    cout << "Chon chuc nang: ";
}

int main() {
    SanPham a[MAX];
    int n = 0;
    int luaChon;

    do {
        hienThiMenu();
        cin >> luaChon;

        switch (luaChon) {
            case 1: {
                hienThiDanhSach(a, n);
                break;
            }
            case 2: {
                int ma;
                cout << "Nhap ma san pham: ";
                cin >> ma;

                int viTri = timTheoMa(a, n, ma);
                if (viTri != -1) {
                    cout << "Ma " << ma << " da ton tai (" << a[viTri].ten << ")." << endl;
                    int soLuongThem;
                    cout << "Nhap so luong can them: ";
                    cin >> soLuongThem;
                    themSanPham(a, n, ma, a[viTri].ten, soLuongThem);
                } else {
                    string ten;
                    int soluong;
                    cout << "Nhap ten san pham: ";
                    cin >> ten;
                    cout << "Nhap so luong: ";
                    cin >> soluong;
                    themSanPham(a, n, ma, ten, soluong);
                }
                break;
            }
            case 3: {
                int maCu, maMoi;
                string tenMoi;
                cout << "Nhap ma san pham can cap nhat: ";
                cin >> maCu;
                cout << "Nhap ma moi: ";
                cin >> maMoi;
                cout << "Nhap ten moi: ";
                cin >> tenMoi;
                capNhatSanPham(a, n, maCu, maMoi, tenMoi);
                break;
            }
            case 4: {
                int ma;
                cout << "Nhap ma san pham can xoa: ";
                cin >> ma;
                xoaTheoMa(a, n, ma);
                break;
            }
            case 5: {
                cout << "Ket thuc chuong trinh!" << endl;
                break;
            }
            default: {
                cout << "Lua chon khong hop le, vui long chon lai!" << endl;
                break;
            }
        }
    } while (luaChon != 5);

    return 0;
}
